from cracker import main

main()