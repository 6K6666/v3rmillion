This cracker only works for unverified email:pass combos.

1. Place your email:pass combos into combos.txt
2. Place your proxies into proxies.txt
3. Run cracker.bat